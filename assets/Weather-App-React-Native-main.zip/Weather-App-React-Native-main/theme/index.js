export const theme = {
   bgWhite: opacity => `rgba(255,255,255, ${opacity})`
}   
